import 'package:flutter/material.dart';
import 'api_service.dart';

class TodosPage extends StatefulWidget {
  const TodosPage({super.key});

  @override
  State<TodosPage> createState() => _TodosPageState();
}

class _TodosPageState extends State<TodosPage> {
  late Future<List<dynamic>> _todos;

  @override
  void initState() {
    super.initState();
    _todos = ApiService.fetchTodos();
  }

  Widget _buildLoading() => const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: Colors.white),
            SizedBox(height: 10),
            Text("Loading Todos...", style: TextStyle(color: Colors.white70)),
          ],
        ),
      );

  Widget _buildError(String message) => Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, color: Colors.redAccent, size: 50),
            const SizedBox(height: 10),
            Text(message, style: const TextStyle(color: Colors.white)),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: () => setState(() => _todos = ApiService.fetchTodos()),
              icon: const Icon(Icons.refresh),
              label: const Text("Retry"),
            )
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(title: const Text("Fetched Todos"), backgroundColor: Colors.deepPurple),
      body: FutureBuilder<List<dynamic>>(
        future: _todos,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return _buildLoading();
          if (snapshot.hasError) return _buildError("Failed to load: ${snapshot.error}");
          if (!snapshot.hasData || snapshot.data!.isEmpty) return _buildError("No data found");

          final todos = snapshot.data!;
          return ListView.builder(
            itemCount: todos.length,
            itemBuilder: (context, index) {
              final todo = todos[index];
              return ListTile(
                leading: Icon(
                  todo["completed"] ? Icons.check_circle : Icons.circle_outlined,
                  color: todo["completed"] ? Colors.green : Colors.grey,
                ),
                title: Text(todo["title"], style: const TextStyle(color: Colors.white)),
                subtitle: Text("ID: ${todo["id"]}", style: const TextStyle(color: Colors.white70)),
              );
            },
          );
        },
      ),
    );
  }
}
