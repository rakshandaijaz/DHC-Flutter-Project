
import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = "https://jsonplaceholder.typicode.com";

  static Future<List<dynamic>> fetchTodos() async {
    try {
      final response = await http.get(Uri.parse("$baseUrl/todos"));
      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);
        if (decoded is List) {
          return decoded;
        } else {
          throw Exception("Unexpected response format for todos");
        }
      } else {
        throw Exception("Failed to fetch todos (Status: ${response.statusCode})");
      }
    } catch (e) {
      throw Exception("Could not fetch todos: $e");
    }
  }

  static Future<Map<String, dynamic>> fetchUser() async {
    try {
      final response =
          await http.get(Uri.parse("$baseUrl/users/1")); // ✅ New public API
      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);
        if (decoded is Map<String, dynamic>) {
          return decoded;
        } else {
          throw Exception("Unexpected response format for user");
        }
      } else {
        throw Exception("Failed to fetch user (Status: ${response.statusCode})");
      }
    } catch (e) {
      throw Exception("Could not fetch user: $e");
    }
  }
}
