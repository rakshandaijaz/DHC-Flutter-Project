import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'task.dart';

class TaskProvider with ChangeNotifier {
  List<Task> _tasks = [];

  List<Task> get tasks => _tasks;

  // ✅ Load tasks from local storage
  Future<void> fetchTasks(String email) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'tasks_$email';
    final savedTasks = prefs.getStringList(key) ?? [];
    _tasks = savedTasks.map((e) => Task.fromMap(jsonDecode(e))).toList();
    notifyListeners();
  }

  // ✅ Add a new task
  Future<void> addTask(String email, String title) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'tasks_$email';

    final newTask = Task(id: DateTime.now().toString(), title: title);
    _tasks.add(newTask);

    final encodedTasks =
        _tasks.map((task) => jsonEncode(task.toMap())).toList();
    await prefs.setStringList(key, encodedTasks);
    notifyListeners();
  }

  // ✅ Toggle done/undone
  Future<void> toggleTask(String email, Task task) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'tasks_$email';

    task.toggleDone();

    final encodedTasks =
        _tasks.map((task) => jsonEncode(task.toMap())).toList();
    await prefs.setStringList(key, encodedTasks);
    notifyListeners();
  }

  // ✅ Delete a task
  Future<void> deleteTask(String email, String id) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'tasks_$email';

    _tasks.removeWhere((task) => task.id == id);

    final encodedTasks =
        _tasks.map((task) => jsonEncode(task.toMap())).toList();
    await prefs.setStringList(key, encodedTasks);
    notifyListeners();
  }
}
