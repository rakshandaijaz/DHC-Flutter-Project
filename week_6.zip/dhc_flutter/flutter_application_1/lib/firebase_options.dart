import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    return const FirebaseOptions(
      apiKey: "AIzaSyBKxg3CA8NbYZ4XtAwHuOsodJIwtqSFSaY",
  authDomain: "flutter-88383.firebaseapp.com",
  projectId: "flutter-88383",
  storageBucket: "flutter-88383.firebasestorage.app",
  messagingSenderId: "868442025087",
  appId: "1:868442025087:web:b874795572e90e849f634a",
  measurementId: "G-C1RCDFXL3N"
    );
  }
}
